package com.midas.app.workflow;

import io.temporal.activity.ActivityOptions;
import io.temporal.workflow.Workflow;
import io.temporal.workflow.WorkflowMethod;

public class AccountWorkflowImpl implements AccountWorkflow {

    // Activity options for handling retries
    private static final ActivityOptions options =
            ActivityOptions.newBuilder()
                    .setStartToCloseTimeout(Duration.ofSeconds(60))
                    .setRetryOptions(
                            RetryOptions.newBuilder()
                                    .setInitialInterval(Duration.ofSeconds(1))
                                    .setMaximumInterval(Duration.ofSeconds(10))
                                    .setDoNotRetry(IllegalArgumentException.class.getName())
                                    .build())
                    .build();

    // Temporal activity to interact with Stripe SDK
    private final StripeActivity stripeActivity = Workflow.newActivityStub(StripeActivity.class, options);

    @Override
    @WorkflowMethod
    public void createStripeCustomer(String id, String email) {
        try {
            // Call the Temporal activity to create a new customer in Stripe
            String stripeCustomerId = stripeActivity.createStripeCustomer(id, email);

            // Handle the Stripe customer ID as needed (e.g., store in the database)
            storeStripeCustomerId(id, stripeCustomerId);

        } catch (Exception e) {
            // Handle any necessary error scenarios
            handleWorkflowError(e);

            // Optionally, initiate a retry or other recovery mechanism
            Workflow.retry("Error creating Stripe customer", e);
        }
    }

    // Method to store the Stripe customer ID in the database (placeholder implementation)
    private void storeStripeCustomerId(String id, String stripeCustomerId) {
        // Implement database storage logic here
        System.out.println("Stored Stripe Customer ID for " + id + ": " + stripeCustomerId);
    }

    // Method to handle workflow-level errors (placeholder implementation)
    private void handleWorkflowError(Exception e) {
        // Implement error handling logic here (e.g., logging, reporting)
        System.err.println("Error in workflow: " + e.getMessage());
    }
}
