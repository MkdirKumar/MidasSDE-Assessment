package com.midas.app.workflow;

import io.temporal.workflow.Workflow;

public interface AccountWorkflow {

    void createStripeCustomer(Account id, Account email);

}
